import axios from 'axios';

// export default axios.create({
//     method: 'get',
//     url: '../screens/components/info'
// });