import React from 'react';
import {View, Text, StyleSheet, TouchableOpacity} from 'react-native';

function Cat(){
    return <View>
        <Text>Hi There!</Text>
    </View>
};

export default Cat;