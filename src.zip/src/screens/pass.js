import React from 'react';
import {View, Text,TouchableOpacity, StyleSheet} from 'react-native';
import Header from './header';
import { withNavigation} from 'react-navigation';

function AboutPass(){
    return <View>
            <Header />
           <Text style={{marginTop: 30}}>Pass Screen</Text>
        </View>
};

export default AboutPass;