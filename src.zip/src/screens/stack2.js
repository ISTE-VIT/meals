import React from 'react';
import {StyleSheet, Text, View} from 'react-native';
import {Ionicons} from '@expo/vector-icons';
import {withNavigation} from 'react-navigation';

function NewHead({navigation}) {
    return (
        <View >
            <Ionicons name="ios-menu" size={45} 
            onPress={() => navigation.openDrawer()} color="white" />
        </View>
    )
};

export default NewHead;