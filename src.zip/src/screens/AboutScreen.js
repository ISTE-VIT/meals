import React from 'react';
import {View, Text,TouchableOpacity, StyleSheet} from 'react-native';
import Header from './header';
import { withNavigation} from 'react-navigation';

function AboutScreen({navigation}){
    var m='orange';
    return <View>
            <Header />
           <Text style={{marginTop: 30}}>About Screen</Text>
        </View>
};

export default AboutScreen;