import React from 'react';
import {StyleSheet, Text, View} from 'react-native';
import {Ionicons} from '@expo/vector-icons';
import {withNavigation} from 'react-navigation';

function Header({navigation}) {
    return (
        <View style={styles.header}>
            <Ionicons name="ios-menu" size={35} style={styles.icon} 
            onPress={() => navigation.openDrawer()} color='white'/>
            <View>
                <Text style={styles.headerText}>Meals</Text>
            </View>
        </View>
    )
};

const styles=StyleSheet.create({
    header: {
        width: '100%',
        height: '24%',
        flexDirection: 'row',
        // alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'gray'
    },
    headerText: {
        fontWeight: 'bold',
        fontSize: 25,
        color: '#333',
        top: 22,
        letterSpacing: 1,
    },
    icon: {
        position: 'absolute',
        left: '6%',
        top: '32%'
    }
});

export default withNavigation(Header);